
## 1. Candy Crush Saga
<p><a href="https://king.com/game/candycrush">Candy Crush Saga</a> is a hit mobile game developed by King (part of Activision|Blizzard) that is played by millions of people all around the world. The game is structured as a series of levels where players need to match similar candy together to (hopefully) clear the level and keep progressing on the level map. If you are one of the few that haven't played Candy Crush, here's a short demo:</p>
<p><a href="https://youtu.be/HGLGxnfs_t8"><img src="https://assets.datacamp.com/production/project_139/img/candy_crush_video.jpeg" alt></a></p>
<p>Candy Crush has more than 3000 levels, and new ones are added every week. That is a lot of levels! And with that many levels, it's important to get <em>level difficulty</em> just right. Too easy and the game gets boring, too hard and players become frustrated and quit playing.</p>
<p>In this project, we will see how we can use data collected from players to estimate level difficulty. Let's start by loading in the packages we're going to need.</p>


```R
# This sets the size of plots to a good default.
options(repr.plot.width = 5, repr.plot.height = 4)

# Loading in packages
# .... YOUR CODE FOR TASK 1 ....
library(dplyr)
library(ggplot2)
library(readr)
```


```R
library(testthat) 
library(IRkernel.testthat)

run_tests({
    test_that("the packages are loaded", {
    expect_true( all(c("package:ggplot2", "package:readr", "package:dplyr") %in% search() ), 
        info = "The dplyr, readr and ggplot2 packages should be loaded using library().")
    })
})
```






    1/1 tests passed


## 2. The data set
<p>The dataset we will use contains one week of data from a sample of players who played Candy Crush back in 2014. The data is also from a single <em>episode</em>, that is, a set of 15 levels. It has the following columns:</p>
<ul>
<li><strong>player_id</strong>: a unique player id</li>
<li><strong>dt</strong>: the date</li>
<li><strong>level</strong>: the level number within the episode, from 1 to 15.</li>
<li><strong>num_attempts</strong>: number of level attempts for the player on that level and date.</li>
<li><strong>num_success</strong>: number of level attempts that resulted in a success/win for the player on that level and date.</li>
</ul>
<p>The granularity of the dataset is player, date, and level. That is, there is a row for every player, day, and level recording the total number of attempts and how many of those resulted in a win.</p>
<p>Now, let's load in the dataset and take a look at the first couple of rows. </p>


```R
# Reading in the data
data <- read_csv("datasets/candy_crush.csv")

# Printing out the first six rows
# .... YOUR CODE FOR TASK 2 ....
head(data)
```

    Parsed with column specification:
    cols(
      player_id = [31mcol_character()[39m,
      dt = [34mcol_date(format = "")[39m,
      level = [32mcol_double()[39m,
      num_attempts = [32mcol_double()[39m,
      num_success = [32mcol_double()[39m
    )



<table>
<caption>A tibble: 6 x 5</caption>
<thead>
	<tr><th scope=col>player_id</th><th scope=col>dt</th><th scope=col>level</th><th scope=col>num_attempts</th><th scope=col>num_success</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;date&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>6dd5af4c7228fa353d505767143f5815</td><td>2014-01-04</td><td> 4</td><td>3</td><td>1</td></tr>
	<tr><td>c7ec97c39349ab7e4d39b4f74062ec13</td><td>2014-01-01</td><td> 8</td><td>4</td><td>1</td></tr>
	<tr><td>c7ec97c39349ab7e4d39b4f74062ec13</td><td>2014-01-05</td><td>12</td><td>6</td><td>0</td></tr>
	<tr><td>a32c5e9700ed356dc8dd5bb3230c5227</td><td>2014-01-03</td><td>11</td><td>1</td><td>1</td></tr>
	<tr><td>a32c5e9700ed356dc8dd5bb3230c5227</td><td>2014-01-07</td><td>15</td><td>6</td><td>0</td></tr>
	<tr><td>b94d403ac4edf639442f93eeffdc7d92</td><td>2014-01-01</td><td> 8</td><td>8</td><td>1</td></tr>
</tbody>
</table>




```R
run_tests({
    test_that("data is read in correctly", {
        correct_data <- read_csv("datasets/candy_crush.csv")
        expect_equal(correct_data, data, 
            info = "data should countain datasets/candy_crush.csv read in using read_csv")
        })
})
```






    1/1 tests passed


## 3. Checking the data set
<p>Now that we have loaded the dataset let's count how many players we have in the sample and how many days worth of data we have.</p>


```R
# Count and display the number of unique players
print("Number of players:")
# .... YOUR CODE FOR TASK 3 ....

# Display the date range of the data
print("Period for which we have data:")
# .... YOUR CODE FOR TASK 3 ....

```

    [1] "Number of players:"
    [1] "Period for which we have data:"



```R
run_tests({
    test_that("nothing", {
        expect_true(TRUE, info = "")
    })
})
```






    1/1 tests passed


## 4. Computing level difficulty
<p>Within each Candy Crush episode, there is a mix of easier and tougher levels. Luck and individual skill make the number of attempts required to pass a level different from player to player. The assumption is that difficult levels require more attempts on average than easier ones. That is, <em>the harder</em> a level is, <em>the lower</em> the probability to pass that level in a single attempt is.</p>
<p>A simple approach to model this probability is as a <a href="https://en.wikipedia.org/wiki/Bernoulli_process">Bernoulli process</a>; as a binary outcome (you either win or lose) characterized by a single parameter <em>p<sub>win</sub></em>: the probability of winning the level in a single attempt. This probability can be estimated for each level as:</p>
<p><img src="https://assets.datacamp.com/production/project_139/img/latex1.png" style="width:150px"></p>
<!-- $$p_{win} = \frac{\sum wins}{\sum attempts}$$ -->
<p>For example, let's say a level has been played 10 times and 2 of those attempts ended up in a victory. Then the probability of winning in a single attempt would be <em>p<sub>win</sub></em> = 2 / 10 = 20%.</p>
<p>Now, let's compute the difficulty <em>p<sub>win</sub></em> separately for each of the 15 levels.</p>


```R
# Calculating level difficulty
difficulty <- data%>%
group_by(level)%>%
 # .... YOUR CODE FOR TASK 4 ....
 summarise(attempts =sum(num_attempts),wins =sum(num_success)) %>%
 # .... YOUR CODE FOR TASK 4 ....
mutate(p_win= wins/attempts)
# Printing out the level difficulty
# .... YOUR CODE FOR TASK 4 ....
print(difficulty)
```

    [38;5;246m# A tibble: 15 x 4[39m
       level attempts  wins  p_win
       [3m[38;5;246m<dbl>[39m[23m    [3m[38;5;246m<dbl>[39m[23m [3m[38;5;246m<dbl>[39m[23m  [3m[38;5;246m<dbl>[39m[23m
    [38;5;250m 1[39m     1     [4m1[24m322   818 0.619 
    [38;5;250m 2[39m     2     [4m1[24m285   666 0.518 
    [38;5;250m 3[39m     3     [4m1[24m546   662 0.428 
    [38;5;250m 4[39m     4     [4m1[24m893   705 0.372 
    [38;5;250m 5[39m     5     [4m6[24m937   634 0.091[4m4[24m
    [38;5;250m 6[39m     6     [4m1[24m591   668 0.420 
    [38;5;250m 7[39m     7     [4m4[24m526   614 0.136 
    [38;5;250m 8[39m     8    [4m1[24m[4m5[24m816   641 0.040[4m5[24m
    [38;5;250m 9[39m     9     [4m8[24m241   670 0.081[4m3[24m
    [38;5;250m10[39m    10     [4m3[24m282   617 0.188 
    [38;5;250m11[39m    11     [4m5[24m575   603 0.108 
    [38;5;250m12[39m    12     [4m6[24m868   659 0.096[4m0[24m
    [38;5;250m13[39m    13     [4m1[24m327   686 0.517 
    [38;5;250m14[39m    14     [4m2[24m772   777 0.280 
    [38;5;250m15[39m    15    [4m3[24m[4m0[24m374  [4m1[24m157 0.038[4m1[24m



```R
data
```


<table>
<caption>A spec_tbl_df: 16865 x 5</caption>
<thead>
	<tr><th scope=col>player_id</th><th scope=col>dt</th><th scope=col>level</th><th scope=col>num_attempts</th><th scope=col>num_success</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;date&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>6dd5af4c7228fa353d505767143f5815</td><td>2014-01-04</td><td> 4</td><td> 3</td><td>1</td></tr>
	<tr><td>c7ec97c39349ab7e4d39b4f74062ec13</td><td>2014-01-01</td><td> 8</td><td> 4</td><td>1</td></tr>
	<tr><td>c7ec97c39349ab7e4d39b4f74062ec13</td><td>2014-01-05</td><td>12</td><td> 6</td><td>0</td></tr>
	<tr><td>a32c5e9700ed356dc8dd5bb3230c5227</td><td>2014-01-03</td><td>11</td><td> 1</td><td>1</td></tr>
	<tr><td>a32c5e9700ed356dc8dd5bb3230c5227</td><td>2014-01-07</td><td>15</td><td> 6</td><td>0</td></tr>
	<tr><td>b94d403ac4edf639442f93eeffdc7d92</td><td>2014-01-01</td><td> 8</td><td> 8</td><td>1</td></tr>
	<tr><td>b94d403ac4edf639442f93eeffdc7d92</td><td>2014-01-05</td><td>12</td><td>15</td><td>1</td></tr>
	<tr><td>ff508e34a5d0157ea5e42f2ff9982660</td><td>2014-01-04</td><td>12</td><td>18</td><td>0</td></tr>
	<tr><td>83ee6c90911dcde3cac189f690310920</td><td>2014-01-04</td><td> 4</td><td> 1</td><td>1</td></tr>
	<tr><td>bef3afe9467a0a4b496a8b72a0840829</td><td>2014-01-07</td><td>15</td><td>27</td><td>0</td></tr>
	<tr><td>bab865e734918e4d680b1be518b9c148</td><td>2014-01-07</td><td>15</td><td>15</td><td>0</td></tr>
	<tr><td>4194741637f27d22b78106cf484a7641</td><td>2014-01-01</td><td> 8</td><td> 8</td><td>0</td></tr>
	<tr><td>701a1c2abd63b53e24782ef52e59e9e4</td><td>2014-01-07</td><td>15</td><td> 3</td><td>0</td></tr>
	<tr><td>cdac1665b7a725f6850682a652e4af34</td><td>2014-01-07</td><td>15</td><td>17</td><td>0</td></tr>
	<tr><td>244ee3e1d8274ab03378223eb4831aa6</td><td>2014-01-07</td><td>15</td><td> 5</td><td>0</td></tr>
	<tr><td>12c0cf02c3a48095b420583fb203ba94</td><td>2014-01-07</td><td>15</td><td> 1</td><td>0</td></tr>
	<tr><td>8d7731a49b66b4c2b76103628f9af49b</td><td>2014-01-07</td><td>15</td><td> 5</td><td>0</td></tr>
	<tr><td>0822ff21d064d90558fa6e9872eb77d5</td><td>2014-01-02</td><td> 9</td><td>15</td><td>0</td></tr>
	<tr><td>a2eb28780561c3e4414efe886fc75888</td><td>2014-01-01</td><td> 8</td><td> 1</td><td>1</td></tr>
	<tr><td>ee7b7171ee4801f52b708ea090bf792b</td><td>2014-01-02</td><td> 9</td><td> 2</td><td>1</td></tr>
	<tr><td>5ddf44f41974acf2c8cd9bbcdb10bc40</td><td>2014-01-02</td><td>10</td><td> 5</td><td>1</td></tr>
	<tr><td>0b3155819caf2a961f093080ad35b1c7</td><td>2014-01-05</td><td>12</td><td> 8</td><td>0</td></tr>
	<tr><td>abd0f49d4c78c41a5e66dad7f6ceffd2</td><td>2014-01-04</td><td> 4</td><td> 1</td><td>1</td></tr>
	<tr><td>e60ef6f316a4e2ac1d5d80957aa2e65e</td><td>2014-01-04</td><td>11</td><td> 1</td><td>1</td></tr>
	<tr><td>fff357d9e487d745b3cdcd8842c55f12</td><td>2014-01-07</td><td>15</td><td> 5</td><td>0</td></tr>
	<tr><td>211a8e2e49f2c639f989e271dc503af1</td><td>2014-01-07</td><td>15</td><td>13</td><td>0</td></tr>
	<tr><td>793f01d46cf8e0a9c25ac195b58b6ab9</td><td>2014-01-03</td><td>10</td><td> 4</td><td>1</td></tr>
	<tr><td>1970080561955b17cac235ba902cde37</td><td>2014-01-03</td><td>10</td><td> 2</td><td>1</td></tr>
	<tr><td>1970080561955b17cac235ba902cde37</td><td>2014-01-07</td><td>14</td><td> 7</td><td>1</td></tr>
	<tr><td>7b59437037dd768bcc5c4e6f64464c61</td><td>2014-01-05</td><td> 5</td><td> 4</td><td>1</td></tr>
	<tr><td>...</td><td>...</td><td>...</td><td>...</td><td>...</td></tr>
	<tr><td>8ec95f673d4422a83a09d08c4bdc8cd3</td><td>2014-01-05</td><td>13</td><td> 4</td><td>1</td></tr>
	<tr><td>93bb7d98554b61dc14d57babd73f05c9</td><td>2014-01-02</td><td> 1</td><td> 1</td><td>1</td></tr>
	<tr><td>6de37d7b40c9b3863ed3be001946b500</td><td>2014-01-04</td><td> 4</td><td> 1</td><td>1</td></tr>
	<tr><td>29abffe0da911d11382bc4319e1a27d1</td><td>2014-01-04</td><td>12</td><td> 9</td><td>1</td></tr>
	<tr><td>c92f049d9876b18e589258877cb5a160</td><td>2014-01-03</td><td>10</td><td> 2</td><td>0</td></tr>
	<tr><td>e441daa8c280af6ce3ecae9f1286cf31</td><td>2014-01-03</td><td> 2</td><td> 2</td><td>1</td></tr>
	<tr><td>3815b1ef8ca0874750ae7ecb56b53891</td><td>2014-01-07</td><td>14</td><td> 1</td><td>1</td></tr>
	<tr><td>b2b95ac1a2d5c95574650efd985ed31c</td><td>2014-01-07</td><td>15</td><td> 7</td><td>1</td></tr>
	<tr><td>bed2510fc2f3b23f65e4b07d426fac4a</td><td>2014-01-05</td><td> 5</td><td> 1</td><td>1</td></tr>
	<tr><td>5883edc0f766b8e8788a2813d71d491c</td><td>2014-01-07</td><td> 7</td><td> 7</td><td>1</td></tr>
	<tr><td>1889352d41a6be6c1715793623719cd5</td><td>2014-01-04</td><td>12</td><td>12</td><td>0</td></tr>
	<tr><td>8e583d18b3f5c662e2d0441dbe39359a</td><td>2014-01-05</td><td> 4</td><td> 1</td><td>1</td></tr>
	<tr><td>d24d961e1c9aedf06dcb06261bb35e12</td><td>2014-01-01</td><td> 8</td><td>33</td><td>0</td></tr>
	<tr><td>d24d961e1c9aedf06dcb06261bb35e12</td><td>2014-01-05</td><td>12</td><td>12</td><td>1</td></tr>
	<tr><td>e145cdeb49f9d5a448c7e005157eab67</td><td>2014-01-04</td><td> 3</td><td> 1</td><td>1</td></tr>
	<tr><td>d56db0e968763255a440b075238008e4</td><td>2014-01-05</td><td>12</td><td> 3</td><td>0</td></tr>
	<tr><td>0cc948608edc2d8b5c37bed486e94f22</td><td>2014-01-01</td><td> 8</td><td> 3</td><td>0</td></tr>
	<tr><td>0cc948608edc2d8b5c37bed486e94f22</td><td>2014-01-05</td><td>12</td><td> 4</td><td>0</td></tr>
	<tr><td>389928c770311ceaa26e5de2436d5a57</td><td>2014-01-02</td><td> 2</td><td> 1</td><td>1</td></tr>
	<tr><td>59aebcabdb904fe53f84cf47441aee5e</td><td>2014-01-05</td><td> 4</td><td> 5</td><td>1</td></tr>
	<tr><td>7ab9b7cffb3ae1e6625a45ed60c409e5</td><td>2014-01-05</td><td>12</td><td> 3</td><td>0</td></tr>
	<tr><td>d40febe8b0c0e9a98b90d66cfff97150</td><td>2014-01-07</td><td>14</td><td> 4</td><td>1</td></tr>
	<tr><td>ee51e02d0ccf314c29fc3479bb290b74</td><td>2014-01-03</td><td>11</td><td> 2</td><td>1</td></tr>
	<tr><td>bd7fc0c2cc8a22f63d7262bbaa68a50e</td><td>2014-01-06</td><td> 5</td><td> 3</td><td>0</td></tr>
	<tr><td>0098ec5725cc2eba7ffb58ca0c77e914</td><td>2014-01-06</td><td> 5</td><td> 3</td><td>1</td></tr>
	<tr><td>e3e95924b152d5d2b0fcf0cc2b8a4261</td><td>2014-01-07</td><td>15</td><td> 1</td><td>1</td></tr>
	<tr><td>712d953e972844194475f21b9352c1ab</td><td>2014-01-01</td><td> 8</td><td> 2</td><td>0</td></tr>
	<tr><td>7fad6b6c0d8c8a5ef69f467511b5262c</td><td>2014-01-01</td><td> 9</td><td>10</td><td>1</td></tr>
	<tr><td>323676bf93f40dda0a96cba8c73c1478</td><td>2014-01-06</td><td>14</td><td> 1</td><td>1</td></tr>
	<tr><td>cda5e442e086f0b9f8d19b18177e4099</td><td>2014-01-01</td><td> 1</td><td> 1</td><td>1</td></tr>
</tbody>
</table>




```R
run_tests({
    test_that("p_win is calculated correctly", {
        correct_difficulty <- data %>%
            group_by(level) %>%
            summarise(attempts = sum(num_attempts), wins = sum(num_success)) %>%
            mutate(p_win = wins / attempts)
        expect_equal(correct_difficulty$p_win, difficulty$p_win, 
            info = "difficulty$p_win should be estimated probability to pass each level in a single attempt")
        })
})
```






    1/1 tests passed


## 5. Plotting difficulty profile
<p><img src="https://assets.datacamp.com/production/project_139/img/tiffi.jpeg" style="height:150px; float:left"> </p>
<p>Great! We now have the difficulty for all the 15 levels in the episode. Keep in mind that, as we measure difficulty as the probability to pass a level in a single attempt, a <em>lower</em> value (a smaller probability of winning the level) implies a <em>higher</em> level difficulty.</p>
<p>Now that we have the difficulty of the episode we should plot it. Let's plot a line graph with the levels on the X-axis and the difficulty (<em>p<sub>win</sub></em>) on the Y-axis. We call this plot the <em>difficulty profile</em> of the episode.</p>


```R
# Plotting the level difficulty profile
# .... YOUR CODE FOR TASK 5 ....
difficulty %>%
  ggplot(aes(x = level, y = p_win)) + 
    geom_line() + 
    scale_x_continuous(breaks = 1:15) +
    scale_y_continuous(label = scales::percent)
```


![png](output_14_0.png)



```R
run_tests({
    test_that("the student plotted a ggplot", {
    expect_true('ggplot' %in% class(last_plot()), 
        info = "You should plot difficulty using ggplot.")
    })
})
```






    1/1 tests passed


## 6. Spotting hard levels
<p>What constitutes a <em>hard</em> level is subjective. However, to keep things simple, we could define a threshold of difficulty, say 10%, and label levels with <em>p<sub>win</sub></em> &lt; 10% as <em>hard</em>. It's relatively easy to spot these hard levels on the plot, but we can make the plot more friendly by explicitly highlighting the hard levels.</p>


```R
# Adding points and a dashed line
# .... YOUR CODE COPIED FROM TASK 5 ....
# .... YOUR CODE FOR TASK 6 ....
difficulty %>%
  ggplot(aes(x = level, y = p_win)) + 
    geom_line() + geom_point() +
    scale_x_continuous(breaks = 1:15) +
    scale_y_continuous(label = scales::percent) +
    geom_hline(yintercept = 0.1, linetype = 'dashed')
```


![png](output_17_0.png)



```R
run_tests({
    plot_layers <- sapply(last_plot()$layers, function(layer)  class(layer$geom)[1])
    test_that("the student has plotted lines, points and a hline", {
    expect_true(all(c('GeomLine', 'GeomPoint', 'GeomHline') %in%  plot_layers), 
        info = "The plot should include lines between the datapoints, points at the datapoints and a horisontal line.")
    })
})
```






    1/1 tests passed


## 7. Computing uncertainty
<p><img src="https://assets.datacamp.com/production/project_139/img/mr_toffee.jpeg" style="height:350px; float:right"> </p>
<p>As Data Scientists we should always report some measure of the uncertainty of any provided numbers. Maybe tomorrow, another sample will give us slightly different values for the difficulties? Here we will simply use the <a href="https://en.wikipedia.org/wiki/Standard_error"><em>Standard error</em></a> as a measure of uncertainty:</p>
<p><img src="https://assets.datacamp.com/production/project_139/img/latex2.png" style="width:115px"></p>
<!-- $$
\sigma_{error} \approx \frac{\sigma_{sample}}{\sqrt{n}}
$$ -->
<p>Here <em>n</em> is the number of datapoints and <em>σ<sub>sample</sub></em> is the sample standard deviation. For a Bernoulli process, the sample standard deviation is: </p>
<p><img src="https://assets.datacamp.com/production/project_139/img/latex3.png" style="width:195px"></p>
<!-- $$
\sigma_{sample} = \sqrt{p_{win} (1 - p_{win})} 
$$ -->
<p>Therefore, we can calculate the standard error like this:</p>
<p><img src="https://assets.datacamp.com/production/project_139/img/latex4.png" style="width:195px"></p>
<!-- $$
\sigma_{error} \approx \sqrt{\frac{p_{win}(1 - p_{win})}{n}}
$$ -->
<p>We already have all we need in the <code>difficulty</code> data frame! Every level has been played <em>n</em> number of times and we have their difficulty <em>p<sub>win</sub></em>. Now, let's calculate the standard error for each level.</p>


```R
# Computing the standard error of p_win for each level
difficulty <- difficulty %>%
    # .... YOUR CODE FOR TASK 7 HERE ....
mutate(error = sqrt(p_win * (1 - p_win) / attempts))
```


```R
run_tests({
    test_that("error is correct", {
        correct_difficulty <- difficulty %>%
            mutate(error = sqrt(p_win * (1 - p_win) / attempts))
        expect_equal(correct_difficulty$error, difficulty$error,
            info = "difficulty$error should be calculated as sqrt(p_win * (1 - p_win) / attempts)")
    })
})
```






    1/1 tests passed


## 8. Showing uncertainty
<p>Now that we have a measure of uncertainty for each levels' difficulty estimate let's use <em>error bars</em> to show this uncertainty in the plot. We will set the length of the error bars to one standard error. The upper limit and the lower limit of each error bar should then be <em>p<sub>win</sub></em> + <em>σ<sub>error</sub></em> and <em>p<sub>win</sub></em> - <em>σ<sub>error</sub></em>, respectively.</p>


```R
# Adding standard error bars
# .... YOUR CODE COPIED FROM TASK 6 ....
# .... YOUR CODE FOR TASK 8 ....
difficulty %>%
  ggplot(aes(x = level, y = p_win)) + 
    geom_line() + geom_point() +
    scale_x_continuous(breaks = 1:15) +
    scale_y_continuous(label = scales::percent) +
    geom_hline(yintercept = 0.1, linetype = 'dashed') +
    geom_errorbar(aes(ymin = p_win - error, ymax = p_win + error))
```


![png](output_23_0.png)



```R
run_tests({
    plot_layers <- sapply(last_plot()$layers, function(layer)  class(layer$geom)[1])
    test_that("the student has plotted lines, points and a hline", {
    expect_true("GeomErrorbar" %in%  plot_layers, 
        info = "The plot should include error bats using geom_errorbar.")
    })
})
```






    1/1 tests passed


## 9. A final metric
<p>It looks like our difficulty estimates are pretty precise! Using this plot, a level designer can quickly spot where the hard levels are and also see if there seems to be too many hard levels in the episode.</p>
<p>One question a level designer might ask is: "How likely is it that a player will complete the episode without losing a single time?" Let's calculate this using the estimated level difficulties!</p>


```R
# The probability of completing the episode without losing a single time
p <- prod(difficulty$p_win)

# Printing it out
p
```


9.44714093448606e-12



```R
run_tests({
    test_that("p is correct", {
        correct_p <- prod(difficulty$p_win)
        expect_equal(correct_p, p,
            info = "p should be calculated as the product of difficulty$p_win .")
    })
})
```






    1/1 tests passed


## 10. Should our level designer worry?
<p>Given the probability we just calculated, should our level designer worry about that a lot of players might complete the episode in one attempt?</p>


```R
# Should our level designer worry about that a lot of 
# players will complete the episode in one attempt?
should_the_designer_worry = FALSE # TRUE / FALSE
```


```R
run_tests({
    test_that("should_the_designer_worry is FALSE", {
    expect_false(should_the_designer_worry,
        info = "The probability is really small, so I don't think the designer should worry that much...")
    })
})
```






    1/1 tests passed

